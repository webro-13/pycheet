def th():
    print('Hello, World!')


def h():
    print('Hello')


def hn(name):
    print('Hello ' + name)

def sh():
    print('Hi')
